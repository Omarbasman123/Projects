#test Q1
def compte100(liste):
    """
    compte100(liste: list[float | int]) -> int
    Retourne le nombre d'éléments dans la liste qui sont supérieurs à 100.
    
    :param liste: Liste de nombres (int ou float)
    :return: Nombre d'éléments supérieurs à 100 dans la liste
    """
    return sum(1 for x in liste if x > 100)

# Exemples
print(compte100([1, 102, -3.5, 104]))          
print(compte100([1, 99, -3.5,-7]))             
print(compte100([]))

#test Q2
def sommeListeDiv2(liste):
    """
    sommeListeDiv2(liste: list[int]) -> int
    Retourne la somme des éléments de la liste qui sont divisibles par 2.
    
    :param liste: Liste d'entiers
    :return: Somme des éléments divisibles par 2 dans la liste
    """
    return sum(x for x in liste if x % 2 == 0)

# Exemples 
print(sommeListeDiv2([1, 4, 3, 8, 5]))    
print(sommeListeDiv2([4, -10, 7]))          
print(sommeListeDiv2([]))

#test Q3
def triples(chaine):
    """
    triples(chaine: str) -> bool
    Retourne True si la chaîne contient au moins une séquence de 3 caractères consécutifs identiques,
    sinon retourne False.
    
    :param chaine: Chaîne de caractères à vérifier
    :return: True si une séquence de 3 caractères consécutifs identiques est trouvée, sinon False
    """
    for i in range(len(chaine) - 2):
        if chaine[i] == chaine[i + 1] == chaine[i + 2]:
            return True
    return False

# Exemples 
print(triples("abaacd"))       
print(triples("abc2eee"))        
print(triples("a23xxxxx"))     
print(triples("abc"))        
print(triples("abbbcdeeggggg"))

#test Q4
def momo(chaine):
    """
    momo(chaine: str) -> str
    Retourne une nouvelle chaîne de caractères contenant les caractères de la chaîne donnée
    une fois chacun, sans répétitions consécutives, et avec le nombre de répétitions pour chaque caractère.
    
    :param chaine: Chaîne de caractères à traiter
    :return: Nouvelle chaîne avec les caractères uniques et leurs occurrences consécutives
    """
    if not chaine:
        return ""
    
    resultat = []
    compteur = 1
    
    
    for i in range(1, len(chaine)):
        if chaine[i] == chaine[i - 1]:
            compteur += 1
        else:
            
            resultat.append(f"{chaine[i - 1]}{compteur}")
            compteur = 1  
    
    
    resultat.append(f"{chaine[-1]}{compteur}")
    
    return "".join(resultat)

# Exemples
print(momo("a"))  
print(momo("aabbbccccx"))    
print(momo("aaa1111"))             
print(momo("aaabcaax"))       
                
#test Q5
def noDup(chaine):
    """
    noDup(chaine: str) -> str
    Retourne une nouvelle chaîne de caractères contenant les caractères de la chaîne donnée
    une fois chacun, sans répétitions consécutives, et dans le même ordre.
    
    :param chaine: Chaîne de caractères à traiter
    :return: Nouvelle chaîne sans répétitions de caractères consécutifs
    """
    if not chaine:
        return ""
    
    resultat = [chaine[0]]
    for i in range(1, len(chaine)):
        if chaine[i] != chaine[i - 1]:
            resultat.append(chaine[i])
    
    return "".join(resultat)

# Exemples
print(noDup("a"))  
print(noDup("aabbbccccx"))        
print(noDup("aaa1111"))          
print(noDup("aaabcaax"))

    


      
