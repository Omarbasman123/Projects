// NOM: OMAR BASMAN ALMOGHLY

package Devoir2_300406240.Partie2;


public class User extends Player {

    public void play(Game game) {
        if(game.getRound() == game.getRows() * game.getColumns()) {
            System.out.println("Game is finished already!");
            return;
        }

        int position;
        boolean validMove = false;

        // Demande à l'utilisateur une entrée valide
        do {
            System.out.print(game.nextBoxSymbol() + " to play: ");
            
            String input = System.console().readLine(); // Lire une ligne de la console

            try {
                position = Integer.parseInt(input) - 1; // Conversion en index (base 0)

                // Vérifie si la position est valide et si la case est vide
                if (position >= 0 && position < game.getRows() * game.getColumns()) {
                    if (game.boxSymbolAt(position) == BoxSymbol.EMPTY) {
                        validMove = true;
                        game.play(position); // Joue le coup
                    } else {
                        System.out.println("This cell has already been played.");
                    }
                } else {
                    System.out.println("Invalid move! Please choose a valid position.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        } while (!validMove);
    }
}

    

