// NOM: OMAR BASMAN ALMOGHLY

package Devoir2_300406240.Partie2;

public enum GameState {
    PLAYING, // ce jeu est en cours
    DRAW,   // ce jeu est un match nul
    XWIN,   // ce jeu a été gagné par le premier joueur X
    OWIN    // ce jeu a été gagné par le premier joueur O
}
    

