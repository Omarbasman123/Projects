//NOM : OMAR BASMAN ALMOGHLY

package Devoir2_300406240.Partie1;

public enum BoxSymbol {
    EMPTY,  // la cellule est vide
    X,   //  il y a un X dans la cellule
    O  // il y a un O dans la cellule
   }