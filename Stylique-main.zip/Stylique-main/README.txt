Team name: Stylique 

Product Name: Stylique 

Brief Product description: 

Are you ready to turn your designs into reality? Visit Stylique! Stylique is a website where you can create and publish your own unique designs. Get the most upvotes on your post and we’ll bring your shirt into life! Plus, you’ll earn 5% of the sales from your designs.  